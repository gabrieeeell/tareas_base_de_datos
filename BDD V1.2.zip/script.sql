DROP DATABASE IF EXISTS ct_usm_postulaciones;
CREATE DATABASE ct_usm_postulaciones;
USE ct_usm_postulaciones;


CREATE TABLE REGION (
    ID_region INT NOT NULL,
    Nombre_region VARCHAR(50) NOT NULL,
    PRIMARY KEY (ID_region)
) ENGINE=InnoDB;

INSERT INTO REGION (ID_region, Nombre_region) VALUES
(1, 'Arica y Parinacota'),
(2, 'Tarapacá'),
(3, 'Antofagasta'),
(4, 'Atacama'),
(5, 'Coquimbo'),
(6, 'Valparaíso'),
(7, 'Metropolitana de Santiago'),
(8, 'Libertador General Bernardo O''Higgins'),
(9, 'Maule'),
(10, 'Ñuble'),
(11, 'Biobío'),
(12, 'La Araucanía'),
(13, 'Los Ríos'),
(14, 'Los Lagos'),
(15, 'Aysén del General Carlos Ibáñez del Campo'),
(16, 'Magallanes y de la Antártica Chilena');

CREATE TABLE SEDE (
    ID_sede INT NOT NULL,
    Nombre_Sede VARCHAR(31) NOT NULL,
    PRIMARY KEY (ID_sede)
) ENGINE=InnoDB;

INSERT INTO SEDE (ID_sede, Nombre_Sede) VALUES
(1, 'Campus Casa Central Valparaíso'),
(2, 'Campus San Joaquín'),
(3, 'Campus Vitacura'),
(4, 'Sede Viña del Mar'),
(5, 'Sede Concepción');

CREATE TABLE ESTADO_POSTULACION (
    ID_estado INT NOT NULL,
    Nombre_estado VARCHAR(11) NOT NULL,
    PRIMARY KEY (ID_estado)
) ENGINE=InnoDB;

INSERT INTO ESTADO_POSTULACION (ID_estado, Nombre_estado) VALUES
(1, 'En Revisión'),
(2, 'Aprobada'),
(3, 'Rechazada'),
(4, 'Cerrada');

CREATE TABLE CARGO_PERSONA (
    ID_cargo INT NOT NULL,
    Nombre_cargo VARCHAR(50) NOT NULL,
    PRIMARY KEY (ID_cargo)
) ENGINE=InnoDB;

INSERT INTO CARGO_PERSONA (ID_cargo, Nombre_cargo) VALUES
(1, 'Estudiante'),
(2, 'Profesor');

CREATE TABLE TIPO_INICIATIVA (
    ID_tipo INT NOT NULL,
    Tipo_iniciativa VARCHAR(9) NOT NULL,
    PRIMARY KEY (ID_tipo)
) ENGINE=InnoDB;

INSERT INTO  TIPO_INICIATIVA(ID_tipo, Tipo_iniciativa) VALUES
(1, 'Nueva'),
(2, 'Existente');

CREATE TABLE JEFE_CARRERA (
    ID_jefe INT NOT NULL,
    Nombre_jefe VARCHAR(50) NOT NULL,
    PRIMARY KEY (ID_jefe)
) ENGINE=InnoDB;

CREATE TABLE COORDINADOR (
    ID_coordinador INT NOT NULL,
    Nombre_coordinador VARCHAR(50) NOT NULL,
    PRIMARY KEY (ID_coordinador)
) ENGINE=InnoDB;

CREATE TABLE TAMANO_EMPRESA (
    ID_tamano INT NOT NULL,
    Nombre_tamano VARCHAR(15) NOT NULL,
    PRIMARY KEY (ID_tamano)
) ENGINE=InnoDB;

INSERT INTO  TAMANO_EMPRESA (ID_tamano, Nombre_tamano) VALUES
(1, 'Microempresa'),
(2, 'Mediana'),
(3, 'Grande');

CREATE TABLE REPRESENTANTE_EMPRESA (
    ID_representante INT NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Mail_representante VARCHAR(255) NOT NULL UNIQUE, 
    Telefono_representante VARCHAR(12) NOT NULL UNIQUE, 
    PRIMARY KEY (ID_representante)
) ENGINE=InnoDB;


CREATE TABLE EMPRESA (
    Rut_Empresa VARCHAR(12) NOT NULL,
    Nombre_empresa VARCHAR(100) NOT NULL,
    Convenio_USM BOOLEAN NOT NULL,
    ID_tamano INT NOT NULL,
    ID_representante INT NOT NULL,
    PRIMARY KEY (Rut_Empresa),
    FOREIGN KEY (ID_tamano) REFERENCES TAMANO_EMPRESA(ID_tamano),
    FOREIGN KEY (ID_representante) REFERENCES REPRESENTANTE_EMPRESA(ID_representante)
) ENGINE=InnoDB;

CREATE TABLE PERSONA (
    RUT_Persona VARCHAR(12) NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Departamento_Area VARCHAR(255) NOT NULL,
    ID_sede INT NOT NULL,
    eMail VARCHAR(255) NOT NULL UNIQUE,
    Telefono VARCHAR(12) UNIQUE,
    ID_cargo INT NOT NULL,
    PRIMARY KEY (RUT_Persona),
    FOREIGN KEY (ID_sede) REFERENCES SEDE(ID_sede),
    FOREIGN KEY (ID_cargo) REFERENCES CARGO_PERSONA(ID_cargo)
) ENGINE=InnoDB;

CREATE TABLE POSTULACION (
    ID_postulacion VARCHAR(20) NOT NULL,
    Numero_postulacion INT NOT NULL UNIQUE,
    Fecha_postulacion DATE NOT NULL,
    Nombre_iniciativa VARCHAR(100) NOT NULL,
    Objetivo_iniciativa VARCHAR(255) NOT NULL,
    Descripcion_soluciones VARCHAR(255) NOT NULL,
    Resultados_esperados VARCHAR(255) NOT NULL,
    Presupuesto INT NOT NULL,
    Rut_Empresa VARCHAR(12) NOT NULL,
    ID_sede INT NOT NULL,
    ID_estado INT NOT NULL,
    ID_region_impacto INT NOT NULL,
    ID_region_origen INT NOT NULL,
    ID_tipo_iniciativa INT NOT NULL,
    ID_jefe INT NOT NULL,
    ID_coordinador INT NOT NULL,
    PRIMARY KEY (ID_postulacion),
    FOREIGN KEY (Rut_Empresa) REFERENCES EMPRESA(Rut_Empresa),
    FOREIGN KEY (ID_sede) REFERENCES SEDE(ID_sede),
    FOREIGN KEY (ID_estado) REFERENCES ESTADO_POSTULACION(ID_estado),
    FOREIGN KEY (ID_region_impacto) REFERENCES REGION(ID_region),
    FOREIGN KEY (ID_region_origen) REFERENCES REGION(ID_region),
    FOREIGN KEY (ID_tipo_iniciativa) REFERENCES TIPO_INICIATIVA(ID_tipo),
    FOREIGN KEY (ID_jefe) REFERENCES JEFE_CARRERA(ID_jefe),
    FOREIGN KEY (ID_coordinador) REFERENCES COORDINADOR(ID_coordinador)
) ENGINE=InnoDB;

CREATE TABLE CRONOGRAMA (
    ID_cronograma INT NOT NULL,
    Etapa VARCHAR(12) NOT NULL,
    Plazos_Semanas INT NOT NULL,
    Entregable VARCHAR(100) NOT NULL,
    ID_postulacion VARCHAR(20) NOT NULL,
    PRIMARY KEY (ID_cronograma),
    FOREIGN KEY (ID_postulacion) REFERENCES POSTULACION(ID_postulacion),
    CHECK (Plazos_Semanas <= 36)
) ENGINE=InnoDB;

CREATE TABLE DOCUMENTO (
    ID_documento INT NOT NULL,
    Archivo BLOB NOT NULL,
    ID_postulacion VARCHAR(20) NOT NULL,
    Tipo VARCHAR(10) NOT NULL,
    PRIMARY KEY (ID_documento),
    FOREIGN KEY (ID_postulacion) REFERENCES POSTULACION(ID_postulacion)
) ENGINE=InnoDB;

CREATE TABLE PERSONA_POSTULACION (
    RUT_Persona VARCHAR(12) NOT NULL,
    ID_postulacion VARCHAR(20) NOT NULL,
    Rol VARCHAR(60) NOT NULL,
    PRIMARY KEY (RUT_Persona, ID_postulacion),
    FOREIGN KEY (RUT_Persona) REFERENCES PERSONA(RUT_Persona),
    FOREIGN KEY (ID_postulacion) REFERENCES POSTULACION(ID_postulacion)
) ENGINE=InnoDB;



